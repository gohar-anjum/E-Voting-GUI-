package acpaftermid;

import javax.swing.*;
import java.awt.*;

public class VoterMainMenu extends JFrame {
    public VoterMainMenu() {
        setTitle("Voter Main Menu");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);

        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(51, 153, 255));
        JLabel titleLabel = new JLabel("Voter Options");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Center Panel with Buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(2, 2, 20, 20));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));

        JButton voteButton = createCustomButton("Vote Now");
        JButton resultsButton = createCustomButton("View Results");

        voteButton.addActionListener(e -> {
            dispose();
            new VotingGUI().setVisible(true);  // Navigate to Voting screen
        });

        resultsButton.addActionListener(e -> {
            dispose();
            new ElectionResultsGUI().setVisible(true);  // View election results
        });

        buttonPanel.add(voteButton);
        buttonPanel.add(resultsButton);

        add(buttonPanel, BorderLayout.CENTER);

        // Footer Panel
        JPanel footerPanel = new JPanel();
        JButton backButton = createCustomButton("Back");
        footerPanel.add(backButton);
        add(footerPanel, BorderLayout.SOUTH);

        backButton.addActionListener(e -> {
            dispose();
            new MainMenu().setVisible(true);  // Back to main menu
        });
    }

    private JButton createCustomButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setBackground(new Color(51, 153, 255));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(200, 40));
        return button;
    }
}
