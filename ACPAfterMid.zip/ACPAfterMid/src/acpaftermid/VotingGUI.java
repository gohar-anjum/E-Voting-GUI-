package acpaftermid;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class VotingGUI extends JFrame {
    public VotingGUI() {
        setTitle("Vote Now");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);

        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(51, 153, 255));
        JLabel headerLabel = new JLabel("Cast Your Vote");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Form Panel
        JPanel formPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        JLabel positionLabel = new JLabel("Select Position:");
        JComboBox<String> positionBox = new JComboBox<>(new String[]{"PM", "CM", "President"});
        JLabel nomineeLabel = new JLabel("Select Nominee:");
        JComboBox<String> nomineeBox = new JComboBox<>();
        JButton voteButton = createCustomButton("Cast Vote");

        formPanel.add(positionLabel);
        formPanel.add(positionBox);
        formPanel.add(nomineeLabel);
        formPanel.add(nomineeBox);

        // Footer Panel
        JPanel footerPanel = new JPanel();
        footerPanel.add(voteButton);
        add(formPanel, BorderLayout.CENTER);
        add(footerPanel, BorderLayout.SOUTH);

        // Load nominees based on selected position
        positionBox.addActionListener(e -> {
            String selectedPosition = (String) positionBox.getSelectedItem();
            nomineeBox.removeAllItems();

            try (Connection conn = DBConnection.getConnection()) {
                String query = "SELECT NomineeID, FullName FROM Nominees WHERE Position = ?";
                PreparedStatement ps = conn.prepareStatement(query);
                ps.setString(1, selectedPosition);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    nomineeBox.addItem(rs.getString("NomineeID") + " - " + rs.getString("FullName"));
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error loading nominees: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Cast vote action
        voteButton.addActionListener(e -> {
            String selectedNominee = (String) nomineeBox.getSelectedItem();
            if (selectedNominee == null) {
                JOptionPane.showMessageDialog(this, "Please select a nominee!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String nomineeID = selectedNominee.split(" - ")[0]; // Extract nominee ID

            try (Connection conn = DBConnection.getConnection()) {
                // Update the votes for the selected nominee
                String voteQuery = "UPDATE Nominees SET Votes = Votes + 1 WHERE NomineeID = ?";
                PreparedStatement ps = conn.prepareStatement(voteQuery);
                ps.setString(1, nomineeID);
                ps.executeUpdate();

                JOptionPane.showMessageDialog(this, "Vote cast successfully!");
                dispose();
                new MainMenu().setVisible(true);  // Go back to the main menu
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error casting vote: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private JButton createCustomButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setBackground(new Color(51, 153, 255));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(150, 40));
        return button;
    }
}
