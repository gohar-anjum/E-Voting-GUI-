package acpaftermid;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class NomineeMainMenu extends JFrame {
    public NomineeMainMenu() {
        setTitle("Nominee Main Menu");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);

        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(51, 153, 255));
        JLabel titleLabel = new JLabel("Nominee Voting Results");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Center Panel for Nominee Details
        JPanel detailsPanel = new JPanel(new GridLayout(2, 1, 10, 10));
        detailsPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        // Fetch the logged-in nominee's email or ID (assuming email is used)
        String nomineeEmail = "nominee@example.com";  // Replace with actual login email or ID

        try (Connection conn = DBConnection.getConnection()) {
            String nomineeQuery = "SELECT FullName, Position, Votes FROM Nominees WHERE Email = ?";
            PreparedStatement psNominee = conn.prepareStatement(nomineeQuery);
            psNominee.setString(1, nomineeEmail);
            ResultSet rsNominee = psNominee.executeQuery();

            if (rsNominee.next()) {
                String nomineeName = rsNominee.getString("FullName");
                String position = rsNominee.getString("Position");
                int nomineeVotes = rsNominee.getInt("Votes");

                // Display the logged-in nominee's votes
                JLabel nomineeDetailsLabel = new JLabel("Nominee: " + nomineeName + " | Position: " + position + " | Votes: " + nomineeVotes);
                detailsPanel.add(nomineeDetailsLabel);
            }

            // Fetch the opponent's votes (all nominees for the same position)
            String opponentQuery = "SELECT FullName, Votes FROM Nominees WHERE Position = ? AND Email != ?";
            PreparedStatement psOpponents = conn.prepareStatement(opponentQuery);
            psOpponents.setString(1, "President");  // Replace with the logged-in nominee's position
            psOpponents.setString(2, nomineeEmail);
            ResultSet rsOpponents = psOpponents.executeQuery();

            JPanel opponentsPanel = new JPanel();
            opponentsPanel.setLayout(new BoxLayout(opponentsPanel, BoxLayout.Y_AXIS));

            while (rsOpponents.next()) {
                String opponentName = rsOpponents.getString("FullName");
                int opponentVotes = rsOpponents.getInt("Votes");

                JLabel opponentLabel = new JLabel(opponentName + " | Votes: " + opponentVotes);
                opponentsPanel.add(opponentLabel);
            }

            detailsPanel.add(opponentsPanel);
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching nominee data: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        add(detailsPanel, BorderLayout.CENTER);

        // Footer Panel with Back Button
        JPanel footerPanel = new JPanel();
        JButton backButton = createCustomButton("Back");
        footerPanel.add(backButton);
        add(footerPanel, BorderLayout.SOUTH);

        backButton.addActionListener(e -> {
            dispose();
            new MainMenu().setVisible(true);  // Back to main menu
        });
    }

    private JButton createCustomButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setBackground(new Color(51, 153, 255));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(200, 40));
        return button;
    }
}
