package acpaftermid;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ElectionResultsGUI extends JFrame {
    public ElectionResultsGUI() {
        setTitle("Election Results");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);

        // Results Area
        JTextArea resultsArea = new JTextArea();
        resultsArea.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        resultsArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultsArea);
        add(scrollPane, BorderLayout.CENTER);

        // Footer Panel
        JPanel footerPanel = new JPanel();
        JButton backButton = createCustomButton("Back");
        footerPanel.add(backButton);
        add(footerPanel, BorderLayout.SOUTH);

        // Load election results
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT Position, FullName, PartyAffiliation, Votes FROM Nominees ORDER BY Position, Votes DESC";
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            StringBuilder results = new StringBuilder("Election Results:\n\n");
            while (rs.next()) {
                results.append("Position: ").append(rs.getString("Position"))
                        .append("\nNominee: ").append(rs.getString("FullName"))
                        .append("\nParty: ").append(rs.getString("PartyAffiliation"))
                        .append("\nVotes: ").append(rs.getInt("Votes"))
                        .append("\n\n");
            }
            resultsArea.setText(results.toString());
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading results: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        backButton.addActionListener(e -> {
            dispose();
            new MainMenu().setVisible(true);  // Back to main menu
        });
    }

    private JButton createCustomButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setBackground(new Color(51, 153, 255));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(150, 40));
        return button;
    }
}
