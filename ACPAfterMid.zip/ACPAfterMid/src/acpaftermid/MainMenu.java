package acpaftermid;

import javax.swing.*;
import java.awt.*;

public class MainMenu extends JFrame {
    public MainMenu() {
        setTitle("E-Voting System");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);

        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(51, 153, 255));
        JLabel titleLabel = new JLabel("Welcome to E-Voting");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Center Panel with Buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(3, 2, 20, 20));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));

        JButton loginButton = createCustomButton("Login");
        JButton registerVoterButton = createCustomButton("Register as Voter");  // Added this button
        JButton registerNomineeButton = createCustomButton("Register as Nominee");
        JButton resultsButton = createCustomButton("View Results");

        loginButton.addActionListener(e -> {
            dispose();
            new LoginGUI().setVisible(true); // Login first
        });

        registerVoterButton.addActionListener(e -> {
            dispose();
            new VoterRegisterGUI().setVisible(true);  // Navigate to Voter Registration
        });

        registerNomineeButton.addActionListener(e -> {
            dispose();
            new NomineeRegisterGUI().setVisible(true);
        });

        resultsButton.addActionListener(e -> {
            dispose();
            new ElectionResultsGUI().setVisible(true);
        });

        buttonPanel.add(loginButton);
        buttonPanel.add(registerVoterButton);  // Add to the grid
        buttonPanel.add(registerNomineeButton);
        buttonPanel.add(resultsButton);

        add(buttonPanel, BorderLayout.CENTER);

        // Footer Panel
        JPanel footerPanel = new JPanel();
        JLabel footerLabel = new JLabel("© 2024 E-Voting System");
        footerPanel.add(footerLabel);
        add(footerPanel, BorderLayout.SOUTH);
    }

    private JButton createCustomButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setBackground(new Color(51, 153, 255));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(200, 40));
        return button;
    }
}
