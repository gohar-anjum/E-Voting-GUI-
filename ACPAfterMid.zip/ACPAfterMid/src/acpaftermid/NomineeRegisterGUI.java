package acpaftermid;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;

public class NomineeRegisterGUI extends JFrame {
    public NomineeRegisterGUI() {
        setTitle("Nominee Registration");
        setSize(500, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);

        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(51, 153, 255));
        JLabel titleLabel = new JLabel("Register as Nominee");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Form Panel
        JPanel formPanel = new JPanel(new GridLayout(8, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        JLabel nameLabel = new JLabel("Full Name:");
        JTextField nameField = new JTextField();
        JLabel partyLabel = new JLabel("Party Affiliation:");
        JTextField partyField = new JTextField();
        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField(); // Added email field for nominee
        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField(); // Added password field for nominee
        JLabel positionLabel = new JLabel("Position:");
        JComboBox<String> positionBox = new JComboBox<>(new String[]{"PM", "CM", "President"});
        JLabel dobLabel = new JLabel("Date of Birth:");
        JFormattedTextField dobField = new JFormattedTextField(new SimpleDateFormat("yyyy-MM-dd"));
        JLabel qualificationsLabel = new JLabel("Qualifications:");
        JTextField qualificationsField = new JTextField();
        JButton registerButton = createCustomButton("Register");

        formPanel.add(nameLabel);
        formPanel.add(nameField);
        formPanel.add(partyLabel);
        formPanel.add(partyField);
        formPanel.add(emailLabel);
        formPanel.add(emailField);  // Added email field for nominee
        formPanel.add(passwordLabel);
        formPanel.add(passwordField);  // Added password field for nominee
        formPanel.add(positionLabel);
        formPanel.add(positionBox);
        formPanel.add(dobLabel);
        formPanel.add(dobField);
        formPanel.add(qualificationsLabel);
        formPanel.add(qualificationsField);

        // Footer Panel
        JPanel footerPanel = new JPanel();
        footerPanel.add(registerButton);
        add(formPanel, BorderLayout.CENTER);
        add(footerPanel, BorderLayout.SOUTH);

        // Register Button Action
        registerButton.addActionListener(e -> {
            String name = nameField.getText().trim();
            String party = partyField.getText().trim();
            String email = emailField.getText().trim();  // Get email input
            String password = new String(passwordField.getPassword()).trim();  // Get password input
            String position = (String) positionBox.getSelectedItem();
            String dob = dobField.getText().trim();
            String qualifications = qualificationsField.getText().trim();

            if (name.isEmpty() || party.isEmpty() || email.isEmpty() || password.isEmpty() || position == null || dob.isEmpty() || qualifications.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try (Connection conn = DBConnection.getConnection()) {
                String query = "INSERT INTO Nominees (FullName, PartyAffiliation, Email, Password, Position, DateOfBirth, Qualifications) VALUES (?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement ps = conn.prepareStatement(query);
                ps.setString(1, name);
                ps.setString(2, party);
                ps.setString(3, email);  // Save email for nominee
                ps.setString(4, password);  // Save password for nominee
                ps.setString(5, position);
                ps.setString(6, dob);
                ps.setString(7, qualifications);
                ps.executeUpdate();

                JOptionPane.showMessageDialog(this, "Nominee registered successfully!");
                dispose();
                new MainMenu().setVisible(true);
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error registering nominee: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private JButton createCustomButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setBackground(new Color(51, 153, 255));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(150, 40));
        return button;
    }
}
